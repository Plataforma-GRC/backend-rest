module.exports.client = {
    rabbitMQ: ""
  };
